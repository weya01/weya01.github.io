/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 11:31:59 by bepereir          #+#    #+#             */
/*   Updated: 2025/09/30 12:20:04 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushSwap.h"

static int	ft_putchar_fd(char c, int fd)
{
	return ((int)write(fd, &c, 1));
}

static int	ft_putnbr_fd(int n, int fd)
{
	int	o;

	o = 0;
	if (n == -2147483648)
		return ((int)write(fd, "-2147483648", 11));
	if (n < 0)
	{
		o += ft_putchar_fd('-', fd);
		n = -n;
	}
	if (n >= 10)
		o += ft_putnbr_fd(n / 10, fd);
	ft_putchar_fd((n % 10) + '0', fd);
	return (o + 1);
}

static int	ft_putstr_fd(char *s, int fd)
{
	int	o;

	o = 0;
	if (!s)
		return ((int)write(fd, "(null)", 6));
	while (*s)
		o += ((int)write(fd, s++, 1));
	return (o);
}

static int	ft_type_handle(const char *format, va_list args)
{
	int	o;

	o = 0;
	if (*format == 'd' || *format == 'i')
		o += ft_putnbr_fd(va_arg(args, int), 1);
	else if (*format == 's')
		o += ft_putstr_fd(va_arg(args, char *), 1);
	else if (*format == 'c')
		o += ft_putchar_fd(va_arg(args, int), 1);
	/*else if (*format == 'x')
		o += ft_putnbr_hex_lo(va_arg(args, unsigned int), 1);
	else if (*format == 'X')
		o += ft_putnbr_hex_up(va_arg(args, unsigned int), 1);
	else if (*format == 'u')
		o += ft_putnbr_unsg(va_arg(args, unsigned int), 1);
	else if (*format == '%')
		o += ft_putchar_fd('%', 1);
	else if (*format == 'p')
		o += ft_putptr(va_arg(args, void *), 1);    */
	return (o);
}

int	ft_printf(const char *format, ...)
{
	va_list	args;
	int		o;

	if (!format)
		return (-1);
	o = 0;
	va_start(args, format);
	while (*format)
	{
		if (*format == '%')
		{
			format++;
			if (*format)
				o += ft_type_handle(format++, args);
			else
				break ;
		}
		else
			o += ft_putchar_fd(*format++, 1);
	}
	va_end(args);
	return (o);
}
