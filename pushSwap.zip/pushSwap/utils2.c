/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 13:49:30 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/08 18:34:19 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushSwap.h"

void	control(t_pilha *A, t_pilha *B)
{
	int			elementoA;
	int			elementoB;
	int			minMoves;
	tt_pilha	pilha_set;

	if (!A)
		return ;
	elementoA = -1;
	elementoB = -1;
	pilha_set.a = A;
	pilha_set.b = B;
	minMoves = INT_MAX;
	pilha_set.deep_a = 0;
	while (pilha_set.a != NULL)
	{
		if (!pilha_set.a->keep)
		{
			pilha_set.deep_a = howDeep(pilha_set.a->indice, A);
			if (pilha_set.deep_a < 0)
				pilha_set.deep_a *= -1;
			control2(pilha_set, &minMoves, &elementoA, &elementoB);
		}
		pilha_set.a = pilha_set.a->next;
	}
	operate(A, B, howDeep(elementoA, A), howDeep(elementoB, B));
}

void	control2(tt_pilha pilha_set, int *minMoves, int *elementoA,
		int *elementoB)
{
	int	dist;

	dist = INT_MAX;
	if (pilha_set.b == NULL)
		if (*minMoves > (pilha_set.deep_a))
		{
			*minMoves = pilha_set.deep_a;
			*elementoA = pilha_set.a->indice;
			dist = pilha_set.a->indice;
			return ;
		}
	while (pilha_set.b != NULL)
	{
		pilha_set.deep_b = howDeep(pilha_set.b->indice, pilha_set.b);
		if (pilha_set.deep_b < 0)
			pilha_set.deep_b *= -1;
		if (dif(pilha_set.a->indice, pilha_set.b->indice) < dist)
			if (*minMoves > (pilha_set.deep_a + pilha_set.deep_b))
			{
				*minMoves = pilha_set.deep_a + pilha_set.deep_b;
				*elementoA = pilha_set.a->indice;
				*elementoB = pilha_set.b->indice;
				dist = dif(pilha_set.a->indice, pilha_set.b->indice);
			}
		pilha_set.b = pilha_set.b->next;
	}
}

void	operate(t_pilha *A, t_pilha *B, int distA, int distB)
{
	t_pilha	**vistor;
	t_pilha	**checker;

	vistor = &A;
	checker = &B;
	if (distA == 1 && distB == 1)
	{
		ft_ss(vistor, checker);
		ft_pb(checker, vistor);
	}
	else if (distA == -1 && distB == -1)
	{
		ft_rrr(vistor, checker);
		ft_rrr(vistor, checker);
		ft_pb(checker, vistor);
	}
	else if (distA == CASO_PARTICULAR && distB == CASO_PARTICULAR)
	{
		ft_rrr(vistor, checker);
		ft_pb(checker, vistor);
	}
	// if (distA >= 1 || distB >= 1) // distA+||distB+1
	operate2(vistor, checker, distA, distB);
	if (distA <= -1 || distB <= -1) // distA-||distB-1
		operate3(vistor, checker, distA, distB);
	// if (distB == 0)
	//	ft_pb(vistor, checker);
}

int	dif(int a, int b)
{
	if (a > b)
		return (a - b);
	else
		return (b - a);
}

int howDeep(int indice, t_pilha *s)
{
    int count = 0;
    int size = stack_size(s);
    t_pilha *a = s;

    // Percorre a lista até achar o índice
    while (a != NULL && a->indice != indice)
    {
        count++;
        a = a->next;
    }

    // Agora, calcula se é mais rápido rotacionar para frente (count positivo)
    // ou para trás (count negativo)
    if (count > size / 2)
        return count - size; // negativo, rotacionar reverso
    else
        return count; // positivo, rotacionar direto
}


// Usar LIS para nao mexer em elementos ja pre ordenados co mmodificacao na estrutura com boolean .keep

void	apply_lis(t_pilha *a)
{
	int	size;
	int	*indices;
	int	*lis_flags;

	size = stack_size(a);
	indices = (int *)malloc(sizeof(int) * size);
	lis_flags = (int *)malloc(sizeof(int) * size);
	if (!indices || !lis_flags)
	{
		free(indices);
		free(lis_flags);
		return ;
	}
	apply_lis_fill_indices(a, indices);
	lis_find(indices, size, lis_flags);
	apply_lis_set_flags(a, lis_flags, size);
	free(indices);
	free(lis_flags);
}
