
#include "pushSwap.h"
#include <stdio.h>
#include <stdlib.h>

//#include <string.h>

// ---------- MAIN ----------

int	main(int argc, char **argv)
{
	t_pilha	*nums;
	int		qtd_tokens;
	int		i;
	int		valor;
	char	**tokens;

	nums = NULL;
	i = 0;
	valor = 0;
	qtd_tokens = 0;
	if (argc == 2)
	{
		tokens = split(argv[1], ' ');
		while (tokens[qtd_tokens])
			qtd_tokens++;
		if (!tokens || !processa_argumentos(tokens, qtd_tokens, &nums))
		{
			if (tokens)
				while (qtd_tokens > 0)
					free(tokens[--qtd_tokens]);
			return (1);
		}
		if (tokens)
			while (qtd_tokens > 0)
				free(tokens[--qtd_tokens]);
	}
	else if (argc > 2)
	{
		if (!processa_argumentos(&argv[1], argc - 1, &nums))
			return (1);
	}
	else
	{
		printf("Uso:\n ./prog \"4 3 2\"\n ou:\n ./prog 4 3 2\n");
		return (1);
	}
	if (tem_duplicatas(nums))
	{
		printf("Erro: números duplicados não são permitidos.\n");
		liberar_pilha(nums);
		return (1);
	}
	atribuir_indices(nums);
	printf("📦 Pilha com índices:\n");
	imprimir_pilha(nums);
	liberar_pilha(nums);
	return (0);
}

/* Libera memória da pilha
void	liberar_pilha(pilha *topo) {
	pilha *tmp;
	while (topo) {
		tmp = topo;
		topo = topo->next;
		free(tmp);
	}
}*/

// ---------- SPLIT IMPLEMENTADO ----------
/*
char	**split(const char *str, char delim, int *count)
{
	int		i = 0, j = 0, inicio = 0, total;
	int		len;
	char	**result;
	int		tam;

	i = 0, j = 0, inicio = 0, total = 0;
	len = strlen(str);
	result = NULL;
	// Contar palavras
	while (i <= len)
	{
		if (str[i] == delim || str[i] == '\0')
		{
			if (i > inicio)
			{
				total++;
			}
			inicio = i + 1;
		}
		i++;
	}
	result = malloc(sizeof(char *) * (total + 1));
	if (!result)
		return (NULL);
	i = 0;
	inicio = 0;
	total = 0;
	while (i <= len)
	{
		if (str[i] == delim || str[i] == '\0')
		{
			if (i > inicio)
			{
				tam = i - inicio;
				result[total] = malloc(tam + 1);
				if (!result[total])
					return (NULL);
				strncpy(result[total], &str[inicio], tam);
				result[total][tam] = '\0';
				total++;
			}
			inicio = i + 1;
		}
		i++;
	}
	result[total] = NULL;
	if (count)
		*count = total;
	return (result);
} */

void	control2_b_to_a(t_pilha *a, t_pilha *vistor,
		int *min_moves, int *elemento_a, int *elemento_b, int *deep_a)
{
	t_pilha *checker;
	int	deep_b;
	int	target_index;
	int	cost;
	
	checker = a;
	while (checker)
	{
		if (checker->indice == vistor->indice)
		{
			deep_b = howDeep(checker->indice, a);
			if (deep_b < 0)
				deep_b *= -1;
			cost = *deep_a + deep_b;
			if (cost < *min_moves)
			{
				*min_moves = cost;
				*elemento_a = find_target_in_a(a, vistor->indice);
				*elemento_b = vistor->indice;
			}
		}
		checker = checker->next;
	}
}

