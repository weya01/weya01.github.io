/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pushSwap.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 11:29:16 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/08 17:43:04 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSHSWAP_H
# define PUSHSWAP_H
# define INT_MAX 2147483647
# define CASO_PARTICULAR -11101

# include <stdarg.h>
# include <stdbool.h>
# include <stddef.h>
# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>

typedef struct t_pilha
{
	int				value;
	int				indice;
	bool			keep;
	struct t_pilha	*next;
}					t_pilha;

typedef struct tt_pilha
{
	struct t_pilha	*a;
	struct t_pilha	*b;
	int				deep_a;
	int				deep_b;
}					tt_pilha;

void				ft_sa(t_pilha **stackA);
void				ft_sb(t_pilha **stackB);
void				ft_ss(t_pilha **stackA, t_pilha **stackB);
void				ft_pa(t_pilha **stackA, t_pilha **stackB);
void				ft_pb(t_pilha **stackB, t_pilha **stackA);
void				ft_ra(t_pilha **stackA);
void				ft_rb(t_pilha **stackB);
void				ft_rr(t_pilha **stackA, t_pilha **stackB);
void				ft_rra(t_pilha **stackA);
void				ft_rrb(t_pilha **stackB);
void				ft_rrr(t_pilha **stackA, t_pilha **stackB);
int					stack_size(t_pilha *x);
t_pilha				*novo_no(int valor);
void				empilhar(t_pilha **topo, int valor);
void				liberar_pilha(t_pilha *topo);
int					tem_duplicatas(t_pilha *topo);
void				atribuir_indices(t_pilha *topo);
int					find_min_index(t_pilha *a);
void				control(t_pilha *A, t_pilha *B);
void				control2(tt_pilha pilha_set, int *minMoves, int *elementoA,
						int *elementoB);
void				operate(t_pilha *A, t_pilha *B, int distA, int distB);
void				operate2(t_pilha **vistor, t_pilha **checker, int distA,
						int distB);
void				operate3(t_pilha **vistor, t_pilha **checker, int distA,
						int distB);
int					dif(int a, int b);
int					howDeep(int indice, t_pilha *s);
void				apply_lis(t_pilha *a);
int					lis_find(int *arr, int size, int *lis_flags);
void				apply_lis_fill_indices(t_pilha *a, int *indices);
void				apply_lis_set_flags(t_pilha *a, int *lis_flags, int size);
void				align_stack(t_pilha **a);

int					find_target_in_a(t_pilha *a, int b_index);
void				control_b_to_a(t_pilha **a, t_pilha **b);
void				control2_b_to_a(tt_pilha pilha_set, int *min_moves,
						int *elemento_a, int *elemento_b);

int					ft_atoi(const char *str);
int					converte_para_int(const char *str, int *out);
char				**split(const char *str, char delim);

int					ft_printf(const char *format, ...);

void				operate_b_to_a(t_pilha **A, t_pilha **B, int distA,
						int distB);
void				operate_b_to_a2(t_pilha **A, t_pilha **B, int distA,
						int distB);
void				operate_b_to_a3(t_pilha **A, t_pilha **B, int distA,
						int distB);

void				clean_b(t_pilha *b);

#endif
