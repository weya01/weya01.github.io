/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operationsA.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 11:14:29 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/08 17:49:53 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushSwap.h"

void	ft_sa(t_pilha **stackA)
{
	t_pilha	*tmp;

	if (!stackA || !*stackA || !(*stackA)->next)
		return ;
	tmp = (*stackA)->next;
	(*stackA)->next = tmp->next;
	tmp->next = *stackA;
	*stackA = tmp;
	ft_printf("sa\n");
}

void	ft_pa(t_pilha **stackA, t_pilha **stackB)
{
	t_pilha	*tmp;

	if (!stackB || !*stackB)
		return ;
	tmp = *stackB;
	*stackB = (*stackB)->next;
	tmp->next = *stackA;
	*stackA = tmp;
	ft_printf("pa\n");
}

void	ft_ra(t_pilha **stackA)
{
	t_pilha	*tmp;
	t_pilha	*tmp_last;

	if (!stackA || !*stackA || !(*stackA)->next)
		return ;
	tmp = *stackA;
	tmp_last = *stackA;
	*stackA = (*stackA)->next;
	while (tmp->next)
		tmp = tmp->next;
	tmp->next = tmp_last;
	tmp_last->next = NULL;
	ft_printf("ra\n");
}

void	ft_rra(t_pilha **stackA)
{
	t_pilha	*tmp;
	t_pilha	*tmp2;
	t_pilha	*old_top;

	tmp2 = NULL;
	if (!stackA || !*stackA || !(*stackA)->next)
		return ;
	tmp = *stackA;
	old_top = *stackA;
	while (tmp->next)
	{
		tmp2 = tmp;
		tmp = tmp->next;
	}
	tmp2->next = NULL;
	tmp->next = old_top;
	*stackA = tmp;
	ft_printf("rra\n");
}

t_pilha	*novo_no(int valor)
{
	t_pilha	*no;

	no = malloc(sizeof(t_pilha));
	if (!no)
		return (NULL);
	no->value = valor;
	no->indice = -1;
	no->next = NULL;
	return (no);
}
