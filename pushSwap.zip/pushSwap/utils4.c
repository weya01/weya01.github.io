/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils4.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/30 00:59:38 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/02 16:46:00 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushSwap.h"

static int	lis_build_lengths(int *arr, int size, int *lengths, int *max_end)
{
	int	i;
	int	j;
	int	max_len;

	i = 0;
	max_len = 0;
	*max_end = 0;
	while (i < size)
	{
		lengths[i] = 1;
		j = 0;
		while (j < i)
		{
			if (arr[j] < arr[i] && lengths[j] + 1 > lengths[i])
				lengths[i] = lengths[j] + 1;
			j++;
		}
		if (lengths[i] > max_len)
		{
			max_len = lengths[i];
			*max_end = i;
		}
		i++;
	}
	return (max_len);
}

static void	lis_mark_flags(int *arr, int size, int *lengths,
			int *lis_flags, int max_end, int max_len)
{
	int	i;
	int	current_len;
	int	current_val;

	current_len = max_len;
	current_val = arr[max_end];
	i = max_end;
	while (i >= 0)
	{
		if (lengths[i] == current_len && arr[i] <= current_val)
		{
			lis_flags[i] = 1;
			current_val = arr[i];
			current_len--;
		}
		else
			lis_flags[i] = 0;
		i--;
	}
}

int	lis_find(int *arr, int size, int *lis_flags)
{
	int	*lengths;
	int	max_len;
	int	max_end;

	lengths = (int *)malloc(sizeof(int) * size);
	if (!lengths)
		return (0);
	max_len = lis_build_lengths(arr, size, lengths, &max_end);
	lis_mark_flags(arr, size, lengths, lis_flags, max_end, max_len);
	free(lengths);
	return (max_len);
}

void	apply_lis_fill_indices(t_pilha *a, int *indices)
{
	int		i;
	t_pilha	*tmp;

	i = 0;
	tmp = a;
	while (tmp)
	{
		indices[i] = tmp->indice;
		tmp = tmp->next;
		i++;
	}
}

void	apply_lis_set_flags(t_pilha *a, int *lis_flags, int size)
{
	int		i;
	t_pilha	*tmp;

	i = 0;
	tmp = a;
	while (i < size && tmp)
	{
		tmp->keep = (lis_flags[i] == 1);
		tmp = tmp->next;
		i++;
	}
}

void	align_stack(t_pilha **a)
{
	int min = find_min_index(*a);
	int depth = howDeep(min, *a);

	if (depth >= 0)
		while (depth-- > 0)
			ft_ra(a);
	else
		while (depth++ < 0)
			ft_rra(a);
}

