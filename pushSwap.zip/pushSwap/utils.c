/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 11:54:16 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/02 17:33:35 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushSwap.h"

static void	copiar_valores(t_pilha *topo, int *array)
{
	int	i;

	i = 0;
	while (topo)
	{
		array[i++] = topo->value;
		topo = topo->next;
	}
}

// Verifica se há números duplicados na pilha
int	tem_duplicatas(t_pilha *topo)
{
	t_pilha	*a;
	t_pilha	*b;

	a = topo;
	while (a)
	{
		b = a->next;
		while (b)
		{
			if (a->value == b->value)
				return (1);
			b = b->next;
		}
		a = a->next;
	}
	return (0);
}

static void	quick_sort(int *a, int l, int r)
{
	int p, i, j, tmp;
	if (l >= r)
		return ;
	p = a[r];
	i = l - 1;
	j = l;
	while (j < r)
	{
		if (a[j] < p)
		{
			tmp = a[++i];
			a[i] = a[j];
			a[j] = tmp;
		}
		j++;
	}
	tmp = a[i + 1];
	a[i + 1] = a[r];
	a[r] = tmp;
	quick_sort(a, l, i);
	quick_sort(a, i + 2, r);
}

// Atribui os índices ordenados
void	atribuir_indices(t_pilha *topo)
{
	int		qtd;
	int		*ordenado;
	t_pilha	*atual;
	int		i;

	qtd = stack_size(topo);
	ordenado = malloc(sizeof(int) * qtd);
	if (!ordenado)
		return ;
	copiar_valores(topo, ordenado);
	quick_sort(ordenado, 0, qtd - 1);
	atual = topo;
	while (atual)
	{
		i = 0;
		while (ordenado[i] != atual->value)
            i++;
        atual->indice = i;
		atual = atual->next;
	}
	free(ordenado);
}

int	find_min_index(t_pilha *a)
{
	int	min;

	min = a->indice;
	while (a)
	{
		if (a->indice < min)
			min = a->indice;
		a = a->next;
	}
	return (min);
}
