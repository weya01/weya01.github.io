/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing2.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 13:45:52 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/02 17:03:31 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushSwap.h"

int	ft_atoi(const char *str)
{
	int		i;
	int		sign;
	long	num;

	i = 0;
	sign = 1;
	num = 0;
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
		i++;
	if (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
			sign = -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		num = num * 10 + (str[i] - '0');
		i++;
	}
	return (sign * num);
}

// Converte string para int com verificação de limites
int	converte_para_int(const char *str, int *out)
{
	long	val;

	val = ft_atoi(str);
	//if (*str != '\0')
	//	return (0);
	if (val < 0 || val > INT_MAX)
		return (0);
	*out = (int)val;
	return (1);
}

static int	count_words(const char *str, char delim)
{
	int	count;
	int	in_word;

	count = 0;
	in_word = 0;
	while (*str)
	{
		if (*str != delim && !in_word)
		{
			in_word = 1;
			count++;
		}
		else if (*str == delim)
			in_word = 0;
		str++;
	}
	return (count);
}

static char	*alloc_word(const char *start, int len)
{
	char	*word;
	int		i;

	i = 0;
	word = malloc(len + 1);
	if (!word)
		return (NULL);
	while (i < len)
	{
		word[i] = start[i];
		i++;
	}
	word[i] = '\0';
	return (word);
}

char	**split(const char *str, char delim)
{
	int		i = 0, j = 0, k;
	char	**res;
	int		words;

	i = 0, j = 0, k = 0;
	words = count_words(str, delim);
	res = malloc(sizeof(char *) * (words + 1));
	if (!res)
		return (NULL);
	while (str[i] && k < words)
	{
		if (str[i] != delim)
		{
			j = i;
			while (str[i] && str[i] != delim)
				i++;
			res[k++] = alloc_word(str + j, i - j);
		}
		else
			i++;
	}
	res[k] = NULL;
	return (res);
}
