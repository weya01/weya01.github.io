/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils5.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/06 11:33:22 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/08 18:04:10 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushSwap.h"

void	operate_b_to_a(t_pilha **vistor, t_pilha **checker, int distA, int distB)
{
	if (distA == 1 && distB == 1)
	{
		ft_ss(vistor, checker);
		ft_pa(vistor, checker);
	}
	else if (distA == -1 && distB == -1)
	{
		ft_rrr(vistor, checker);
		ft_rrr(vistor, checker);
		ft_pa(vistor, checker);
	}
	else if (distA == CASO_PARTICULAR && distB == CASO_PARTICULAR)
	{
		ft_rrr(vistor, checker);
		ft_pa(vistor, checker);
	}
	//if (distA >= 1 || distB >= 1) // distA+||distB+
	operate_b_to_a2(vistor, checker, distA, distB);
	if (distA <= -1 || distB <= -1) // distA-||distB-
		operate_b_to_a3(vistor, checker, distA, distB);
}

void	operate_b_to_a2(t_pilha **vistor, t_pilha **checker, int distA, int distB)
{
	if (distA >= 0 || distB >= 0) // distA+||distB+
	{
		while (distA > 0 && distB > 0)
		{
			ft_rr(vistor, checker);
			distA--;
			distB--;
		}
		while (distB != 0 && distB > -1)
		{
			ft_rb(checker);
			distB--;
		}
		while (distA != 0 && distB > -1)
		{
			ft_ra(vistor);
			distA--;
		}
		if (distA == 0 && distB == 0)
			ft_pa(vistor, checker);
	}
    if (distA == 0 && distB == 0)
        ft_pa(vistor, checker);
}

void	operate_b_to_a3(t_pilha **vistor, t_pilha **checker, int distA, int distB)
{
	
	if (distB == CASO_PARTICULAR)
		ft_rrb(checker);
	if (distA == CASO_PARTICULAR)
		ft_rra(vistor);
	while (distA < 1 && distB < 1 && distB != CASO_PARTICULAR
		&& distA != CASO_PARTICULAR)
	{
		ft_rrr(vistor, checker);
		distA++;
		distB++;
	}
	while (distB < 1 && distB != CASO_PARTICULAR)
	{
		ft_rrb(checker);
		distB++;
	}
	while (distA < 1 && distA != CASO_PARTICULAR)
	{
		ft_rra(vistor);
		distA++;
	}
	if (((distA == 0 || distA == 1 || distA == CASO_PARTICULAR) && (distB == 1
				|| distB == 0 || distB == CASO_PARTICULAR)))
		ft_pa(vistor, checker);
	printf("SAINDO DE operate3 (DistA: %d, DistB: %d)\n", distA, distB);
}
