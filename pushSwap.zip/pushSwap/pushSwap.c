/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pushSwap.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 11:10:43 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/08 18:08:42 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushSwap.h"

void	imprimir_pilha(t_pilha *topo)
{
	if (!topo)
		return;
	while (topo)
	{
		printf("Valor: %d, Índice ordenado: %d, keep: %d\n", topo->value, topo->indice, topo->keep);
		topo = topo->next;
	}
}

int	processa_argumentos(char **args, int n, t_pilha **nums)
{
	int	i;
	int	valor;

	i = n - 1;
	while (i >= 0)
	{
		if (!converte_para_int(args[i], &valor))
		{
			printf("Erro: entrada inválida: '%s'\n", args[i]);
			liberar_pilha(*nums);
			return (0);
		}
		empilhar(nums, valor);
		i--;
	}
	return (1);
}

int	stack_sorted(t_pilha *a)
{
	while (a && a->next)
	{
		if (a->indice < a->next->indice)
			return (0);
		a = a->next;
	}
	return (1);
}

int	main(int argc, char **argv)
{
	t_pilha	*nums;
	t_pilha	*b;
	int		qtd_tokens;
	int		i;
	int		valor;
	char	**tokens;

	nums = NULL;
	i = 0;
	valor = 0;
	qtd_tokens = 0;
	//b = malloc(sizeof(t_pilha));
	b = NULL;
	if (argc == 2)
	{
		tokens = split(argv[1], ' ');
		while (tokens[qtd_tokens])
			qtd_tokens++;
		if (!tokens || !processa_argumentos(tokens, qtd_tokens, &nums))
		{
			if (tokens)
			{
				while (qtd_tokens > 0)
					free(tokens[--qtd_tokens]);
				free(tokens);
			}
			return (1);
		}
		if (tokens)
			while (qtd_tokens > 0)
				free(tokens[--qtd_tokens]);
			free(tokens);
	}
	else if (argc > 2)
	{
		if (!processa_argumentos(&argv[1], argc - 1, &nums))
			return (1);
	}
	else
	{
		printf("Uso:\n ./prog \"4 3 2\"\n ou:\n ./prog 4 3 2\n");
		return (1);
	}
	if (tem_duplicatas(nums))
	{
		printf("Erro: números duplicados não são permitidos.\n");
		liberar_pilha(nums);
		return (1);
	}
	atribuir_indices(nums);
	apply_lis(nums);
	printf("📦 Pilha com índices:\n");
	imprimir_pilha(nums);
	/*
	printf("\n");
	ft_pb(&b, &nums);
	printf("\n");
	imprimir_pilha(nums);
	*/
	printf("\nImprimimos B:\n");
	imprimir_pilha(b);
	
	if (!stack_sorted(nums)) //originalmente while
		control(nums, b);
	
	printf("\nImprimimos A STACK ORIGINAL\n");
	imprimir_pilha(nums);
	printf("Imprimimos B:\n");
	imprimir_pilha(b);
	printf("\n");
	while (b != NULL) //originalmente while
	{
		control_b_to_a(&nums, &b);
		break;
	}
	t_pilha *tmp = nums;
	align_stack(&tmp);
	printf("Final\n:");
	imprimir_pilha(nums);
	liberar_pilha(nums);
	free(b);
	return (0);
}
/*
int	main(int argc, char **argv)
{
	pilha *a = parse_args(argc, argv);
	pilha *b = NULL;

	atribuir_indices(a); // cria os .indice com base no sort
	apply_lis(a);      // marca os .keep baseados na LIS

	while (!stack_sorted(a) || b != NULL)
	{
		control(a, b); // já ignora os keep == true
		// dentro de control(), operate() move elementos de A para B
	}

	while (b)
		control_b_to_a(&a, &b);

	// Finaliza com ajustes (traz menor para o topo de A)
	align_stack(&a);

	// free etc.
} */
