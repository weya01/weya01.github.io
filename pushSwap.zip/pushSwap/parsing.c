/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/30 11:01:17 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/08 18:32:07 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include "pushSwap.h"

void clean_b(t_pilha *b)
{
    if (!b)
        return;
    if (b->value == 0 && b->indice == 0)
        b = b->next;
}

int indice_existe(t_pilha *s, int indice)
{
    while (s)
    {
        if (s->indice == indice)
            return 1;
        s = s->next;
    }
    return 0;
}
