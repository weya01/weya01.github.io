/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operationsAB.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 11:20:03 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/08 18:35:21 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushSwap.h"

int	stack_size(t_pilha *x)
{
	int		count;
	t_pilha	*tmp;

	count = 0;
	tmp = x;
	if (!tmp)
		return (0);
	while (tmp)
	{
		count++;
		tmp = tmp->next;
	}
	return (count);
}

void	liberar_pilha(t_pilha *topo)
{
	t_pilha	*tmp;

	while (topo)
	{
		tmp = topo;
		topo = topo->next;
		free(tmp);
	}
}

void	ft_ss(t_pilha **stackA, t_pilha **stackB)
{
	ft_sa(stackA);
	ft_sb(stackB);
}

void	ft_rr(t_pilha **stackA, t_pilha **stackB)
{
	ft_ra(stackA);
	ft_rb(stackB);
}

void	ft_rrr(t_pilha **stackA, t_pilha **stackB)
{
	ft_rra(stackA);
	ft_rrb(stackB);
}
