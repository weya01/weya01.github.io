/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operationsB.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 11:16:53 by bepereir          #+#    #+#             */
/*   Updated: 2025/11/22 18:38:53 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

void	ft_sb(t_pilha **stackB)
{
	t_pilha	*tmp;

	if (!stackB || !*stackB || !(*stackB)->next)
		return ;
	tmp = (*stackB)->next;
	(*stackB)->next = tmp->next;
	tmp->next = *stackB;
	*stackB = tmp;
	write(1, "sb\n", 3);
}

void	ft_pb(t_pilha **stackB, t_pilha **stackA)
{
	t_pilha	*tmp;

	if (!stackA || !*stackA)
		return ;
	tmp = *stackA;
	*stackA = (*stackA)->next;
	tmp->next = *stackB;
	*stackB = tmp;
	write(1, "pb\n", 3);
}

void	ft_rb(t_pilha **stackB)
{
	t_pilha	*tmp;
	t_pilha	*tmp_last;

	if (!stackB || !*stackB || !(*stackB)->next)
		return ;
	tmp = *stackB;
	tmp_last = *stackB;
	*stackB = (*stackB)->next;
	while (tmp->next)
		tmp = tmp->next;
	tmp->next = tmp_last;
	tmp_last->next = NULL;
	write(1, "rb\n", 3);
}

void	ft_rrb(t_pilha **stackB)
{
	t_pilha	*tmp;
	t_pilha	*tmp2;
	t_pilha	*old_top;

	tmp2 = NULL;
	if (!stackB || !*stackB || !(*stackB)->next)
		return ;
	tmp = *stackB;
	old_top = *stackB;
	while (tmp->next)
	{
		tmp2 = tmp;
		tmp = tmp->next;
	}
	tmp2->next = NULL;
	tmp->next = old_top;
	*stackB = tmp;
	write(1, "rrb\n", 4);
}

// Empilha no fim
void	empilhar(t_pilha **topo, int valor)
{
	t_pilha		*no;
	t_pilha		*pilha;

	no = novo_no(valor);
	if (!no)
		return ;
	no->next = NULL;
	if (*topo == NULL)
	{
		*topo = no;
		return ;
	}
	pilha = *topo;
	while (pilha->next)
		pilha = pilha->next;
	pilha->next = no;
}
