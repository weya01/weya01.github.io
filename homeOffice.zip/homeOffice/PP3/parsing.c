/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 13:45:52 by bepereir          #+#    #+#             */
/*   Updated: 2025/12/04 15:27:08 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

long	ft_atoi(const char *str)
{
	int		i;
	int		sign;
	long	num;

	i = 0;
	sign = 1;
	num = 0;
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
		i++;
	if (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
			sign = -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		num = num * 10 + (str[i] - '0');
		i++;
	}
	return (sign * num);
}

static int	is_space(char c)
{
	return (c == ' ' || c == '\t');
}

static int	count_words(const char *str)
{
	int	count;
	int	in_word;

	count = 0;
	in_word = 0;
	while (*str)
	{
		if (!is_space(*str) && !in_word)
		{
			in_word = 1;
			count++;
		}
		else if (is_space(*str))
			in_word = 0;
		str++;
	}
	return (count);
}

static char	*alloc_word(const char *start, int len)
{
	char	*word;
	int		i;

	i = 0;
	word = malloc(len + 1);
	if (!word)
		return (NULL);
	while (i < len)
	{
		word[i] = start[i];
		i++;
	}
	word[i] = '\0';
	return (word);
}

char	**split(const char *str)
{
	t_ints	cont;
	char	**res;
	int		words;

	cont.i = 0;
	cont.j = 0;
	cont.k = 0;
	words = count_words(str);
	res = malloc(sizeof(char *) * (words + 1));
	if (!res)
		return (NULL);
	while (str[cont.i] && cont.k < words)
	{
		if (!is_space(str[cont.i]))
		{
			cont.j = cont.i;
			while (str[cont.i] && !is_space(str[cont.i]))
				cont.i++;
			res[cont.k++] = alloc_word(str + cont.j, cont.i - cont.j);
		}
		else
			cont.i++;
	}
	res[cont.k] = NULL;
	return (res);
}
