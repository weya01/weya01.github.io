/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils1.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/30 11:01:17 by bepereir          #+#    #+#             */
/*   Updated: 2025/11/22 21:04:58 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

void	set_moves(t_tpilha pilha_set, int *min_moves, int *elemento_a,
		int *elemento_b)
{
	*min_moves = pilha_set.deep_a + pilha_set.deep_b;
	*elemento_a = pilha_set.a->indice;
	*elemento_b = pilha_set.b->indice;
}

void	liberar_pilha(t_pilha *topo)
{
	t_pilha	*tmp;

	while (topo)
	{
		tmp = topo;
		topo = topo->next;
		free(tmp);
	}
}

void	sort_three(t_pilha **a)
{
	int	x;
	int	y;
	int	z;

	x = (*a)->value;
	y = (*a)->next->value;
	z = (*a)->next->next->value;
	if (x > y && y < z && x < z)
		ft_sa(a);
	else if (x > y && y > z)
	{
		ft_sa(a);
		ft_rra(a);
	}
	else if (x > y && y < z && x > z)
		ft_ra(a);
	else if (x < y && y > z && x < z)
	{
		ft_sa(a);
		ft_ra(a);
	}
	else if (x < y && y > z && x > z)
		ft_rra(a);
}

int	is_digit(const char *c)
{
	int	i;

	i = 0;
	if (c[i] == '-' || c[i] == '+')
		i++;
	while (c[i])
	{
		if (c[i] < 48 || c[i] > 57)
			return (0);
		i++;
	}
	return (1);
}
