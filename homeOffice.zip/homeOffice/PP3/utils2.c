/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 13:49:30 by bepereir          #+#    #+#             */
/*   Updated: 2025/11/22 22:08:26 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

void	control(t_pilha **A, t_pilha **B)
{
	int			elemento_a;
	int			elemento_b;
	int			min_moves;
	t_tpilha	pilha_set;

	if (!A)
		return ;
	pilha_set.a = *A;
	elemento_a = -1;
	elemento_b = -1;
	pilha_set.b = *B;
	min_moves = INT_MAX;
	pilha_set.deep_a = 0;
	while (pilha_set.a != NULL)
	{
		pilha_set.deep_a = how_deep(pilha_set.a->indice, *A);
		pilha_set.special = how_deep(pilha_set.a->indice, *A);
		if (pilha_set.deep_a < 0)
			pilha_set.deep_a *= -1;
		control2(pilha_set, &min_moves, &elemento_a, &elemento_b);
		pilha_set.a = pilha_set.a->next;
	}
	operate(A, B, how_deep(elemento_a, *A), how_deep(elemento_b, *B));
}

static void	aux_control2(t_tpilha pilha_set, int *min_moves, int *elemento_a,
		int *elemento_b)
{
	int	moves;
	int	best_b_pos;

	best_b_pos = find_correct_b_position(pilha_set.b, pilha_set.a->indice);
	pilha_set.deep_b = how_deep(best_b_pos, pilha_set.b);
	if (pilha_set.special > 0 && pilha_set.deep_b > 0)
	{
		if (pilha_set.special > pilha_set.deep_b)
			moves = pilha_set.special + 1;
		else
			moves = pilha_set.deep_b + 1;
	}
	else
	{
		if (pilha_set.deep_b < 0)
			pilha_set.deep_b *= -1;
		moves = pilha_set.deep_a + pilha_set.deep_b + 1;
		if (moves < *min_moves)
		{
			*min_moves = moves;
			*elemento_a = pilha_set.a->indice;
			*elemento_b = best_b_pos;
		}
	}
}

void	control2(t_tpilha pilha_set, int *min_moves, int *elemento_a,
		int *elemento_b)
{
	int	moves;

	if (pilha_set.b == NULL)
	{
		moves = pilha_set.deep_a + 1;
		if (moves < *min_moves)
		{
			*min_moves = moves;
			*elemento_a = pilha_set.a->indice;
			*elemento_b = -1;
		}
		return ;
	}
	aux_control2(pilha_set, min_moves, elemento_a, elemento_b);
}

void	operate(t_pilha **A, t_pilha **B, int distA, int distB)
{
	t_pilha	**vistor;
	t_pilha	**checker;

	vistor = A;
	checker = B;
	if (stack_size(*vistor) == 3)
		sort_three(vistor);
	if (stack_size(*vistor) == 3)
		return ;
	if (distA == 1 && distB == 1)
	{
		ft_ss(vistor, checker);
		ft_pb(checker, vistor);
		return ;
	}
	else if (distA == -1 && distB == -1)
	{
		ft_rrr(vistor, checker);
		ft_rrr(vistor, checker);
		ft_pb(checker, vistor);
		return ;
	}
	operate2(vistor, checker, distA, distB);
	operate3(vistor, checker, distA, distB);
	ft_pb(checker, vistor);
}

void	msg_error(char *msg, t_pilha *a)
{
	write(STDERR_FILENO, msg, ft_strlen(msg));
	if (a)
		liberar_pilha(a);
}
