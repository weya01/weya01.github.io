/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils4.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/30 00:59:38 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/29 11:44:49 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

int	dif(int a, int b)
{
	if (a > b)
		return (a - b);
	else
		return (b - a);
}

int	how_deep(int indice, t_pilha *s)
{
	int		count;
	int		size;
	t_pilha	*a;

	count = 0;
	size = stack_size(s);
	a = s;
	while (a != NULL && a->indice != indice)
	{
		count++;
		a = a->next;
	}
	if (count > size / 2)
		return (count - size);
	else
		return (count);
}

static t_pilha	*find_max(t_pilha *tmp)
{
	t_pilha	*max_b;
	t_pilha	*aux;

	if (!tmp)
		return (NULL);
	max_b = tmp;
	aux = tmp;
	while (aux)
	{
		if (aux->indice > max_b->indice)
			max_b = aux;
		aux = aux->next;
	}
	return (max_b);
}

static int	best_b_position(t_pilha *tmp, t_pilha *b, t_tpilha *best_e_indice,
		t_pilha *max_b)
{
	t_pilha	*next;
	int		best_diff;
	int		diff;

	best_diff = INT_MAX;
	while (tmp)
	{
		if (tmp->next)
			next = tmp->next;
		else
			next = b;
		if (tmp->indice > best_e_indice->special
			&& next->indice < best_e_indice->special)
			return (next->indice);
		diff = dif(tmp->indice, best_e_indice->special);
		if (diff < best_diff)
		{
			best_diff = diff;
			best_e_indice->a = tmp;
		}
		tmp = tmp->next;
	}
	if (best_e_indice->a)
		return (best_e_indice->a->indice);
	return (max_b->indice);
}

int	find_correct_b_position(t_pilha *b, int a_indice)
{
	t_pilha		*tmp;
	t_pilha		*max_b;
	t_tpilha	best_e_indice;
	int			target;

	if (!b)
		return (-1);
	tmp = b;
	best_e_indice.special = a_indice;
	best_e_indice.a = NULL;
	max_b = find_max(tmp);
	target = best_b_position(tmp, b, &best_e_indice, max_b);
	return (target);
}
