/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils5.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/06 11:33:22 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/29 11:47:45 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

void	operate_b_to_a(t_pilha **vistor, t_pilha **checker, int distA,
		int distB)
{
	if (distA == 1 && distB == 1)
	{
		ft_ra(vistor);
		ft_rb(checker);
		ft_pa(vistor, checker);
		return ;
	}
	if (distA == -1 && distB == -1)
	{
		ft_rrr(vistor, checker);
		ft_rrr(vistor, checker);
		ft_pa(vistor, checker);
		return ;
	}
	else if (distA == CASO_PARTICULAR && distB == CASO_PARTICULAR)
	{
		ft_rrr(vistor, checker);
		ft_pa(vistor, checker);
		return ;
	}
	operate_b_to_a2(vistor, checker, distA, distB);
	operate_b_to_a3(vistor, checker, distA, distB);
	ft_pa(vistor, checker);
}

void	operate_b_to_a2(t_pilha **vistor, t_pilha **checker, int distA,
		int distB)
{
	while (distA > 0 && distB > 0)
	{
		ft_rr(vistor, checker);
		distA--;
		distB--;
	}
	while (distB > 0)
	{
		ft_rb(checker);
		distB--;
	}
	while (distA > 0)
	{
		ft_ra(vistor);
		distA--;
	}
}

void	operate_b_to_a3(t_pilha **vistor, t_pilha **checker, int distA,
		int distB)
{
	if (distB == CASO_PARTICULAR)
		ft_rrb(checker);
	if (distA == CASO_PARTICULAR)
		ft_rra(vistor);
	while (distA < 0 && distB < 0 && distB != CASO_PARTICULAR
		&& distA != CASO_PARTICULAR)
	{
		ft_rrr(vistor, checker);
		distA++;
		distB++;
	}
	while (distB < 0 && distB != CASO_PARTICULAR)
	{
		ft_rrb(checker);
		distB++;
	}
	while (distA < 0 && distA != CASO_PARTICULAR)
	{
		ft_rra(vistor);
		distA++;
	}
}

void	align_stack(t_pilha **a)
{
	int	min;
	int	depth;

	min = find_min_index(*a);
	depth = how_deep(min, *a);
	if (depth >= 0)
		while (depth-- > 0)
			ft_ra(a);
	else
		while (depth++ < 0)
			ft_rra(a);
}

t_pilha	*find_node_by_index(t_pilha *stack, int index)
{
	while (stack)
	{
		if (stack->indice == index)
			return (stack);
		stack = stack->next;
	}
	return (NULL);
}
