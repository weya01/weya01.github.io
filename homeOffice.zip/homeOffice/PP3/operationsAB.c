/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operationsAB.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 11:20:03 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/24 16:25:00 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

int	stack_size(t_pilha *x)
{
	int		count;
	t_pilha	*tmp;

	count = 0;
	tmp = x;
	if (!tmp)
		return (0);
	while (tmp)
	{
		count++;
		tmp = tmp->next;
	}
	return (count);
}

void	ft_ss(t_pilha **stackA, t_pilha **stackB)
{
	t_pilha	*tmp;

	if (!stackA || !*stackA || !(*stackA)->next)
		return ;
	tmp = (*stackA)->next;
	(*stackA)->next = tmp->next;
	tmp->next = *stackA;
	*stackA = tmp;
	if (!stackB || !*stackB || !(*stackB)->next)
		return ;
	tmp = (*stackB)->next;
	(*stackB)->next = tmp->next;
	tmp->next = *stackB;
	*stackB = tmp;
	write(1, "ss\n", 3);
}

void	ft_rr(t_pilha **stackA, t_pilha **stackB)
{
	t_pilha	*tmp;
	t_pilha	*tmp_last;

	if (!stackA || !*stackA || !(*stackA)->next)
		return ;
	tmp = *stackA;
	tmp_last = *stackA;
	*stackA = (*stackA)->next;
	while (tmp->next)
		tmp = tmp->next;
	tmp->next = tmp_last;
	tmp_last->next = NULL;
	if (!stackB || !*stackB || !(*stackB)->next)
		return ;
	tmp = *stackB;
	tmp_last = *stackB;
	*stackB = (*stackB)->next;
	while (tmp->next)
		tmp = tmp->next;
	tmp->next = tmp_last;
	tmp_last->next = NULL;
	write(1, "rr\n", 3);
}

static void	ft_rrr2(t_pilha **stackB)
{
	t_pilha	*tmp;
	t_pilha	*tmp2;

	tmp2 = NULL;
	if (!stackB || !*stackB || !(*stackB)->next)
		return ;
	tmp = *stackB;
	while (tmp->next)
	{
		tmp2 = tmp;
		tmp = tmp->next;
	}
	tmp2->next = NULL;
	tmp->next = *stackB;
	*stackB = tmp;
}

void	ft_rrr(t_pilha **stackA, t_pilha **stackB)
{
	t_pilha	*tmp;
	t_pilha	*tmp2;

	tmp2 = NULL;
	if (!stackA || !*stackA || !(*stackA)->next)
		return ;
	tmp = *stackA;
	while (tmp->next)
	{
		tmp2 = tmp;
		tmp = tmp->next;
	}
	tmp2->next = NULL;
	tmp->next = *stackA;
	*stackA = tmp;
	ft_rrr2(stackB);
	write(1, "rrr\n", 4);
}
