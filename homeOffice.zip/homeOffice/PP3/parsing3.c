/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing3.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/12/04 15:28:38 by bepereir          #+#    #+#             */
/*   Updated: 2025/12/04 15:29:09 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

int	converte_para_int(const char *str, int *out)
{
	long	val;

	if (str == NULL)
		return (0);
	if (!is_digit(str))
		return (0);
	if (!very_ft_atoi(str))
		return (0);
	val = ft_atoi(str);
	if (val > INT_MAX)
		return (0);
	*out = (int)val;
	return (1);
}
