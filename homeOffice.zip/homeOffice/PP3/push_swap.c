/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/25 11:10:43 by bepereir          #+#    #+#             */
/*   Updated: 2025/12/04 15:25:12 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

void	error_handling(t_pilha **nums, char **matriz)
{
	int	i;

	i = 0;
	liberar_pilha(*nums);
	while (matriz[i])
	{
		free(matriz[i]);
		i++;
	}
	free(matriz);
}

int	processa_argumentos(char **args, t_ints **n, t_pilha **nums)
{
	int		valor;
	char	**matriz;

	(*n)->j = 1;
	while ((*n)->j <= (*n)->i)
	{
		(*n)->k = -1;
		matriz = split(args[(*n)->j]);
		while (matriz[++(*n)->k])
		{
			if (!converte_para_int(matriz[(*n)->k], &valor))
			{
				error_handling(nums, matriz);
				return (0);
			}
			empilhar(nums, valor);
		}
		(*n)->k = -1;
		while (matriz[++(*n)->k])
			free(matriz[(*n)->k]);
		free(matriz);
		(*n)->j++;
	}
	return (1);
}

int	stack_sorted2(t_pilha *a)
{
	int		breaks;
	t_pilha	*start;

	breaks = 0;
	start = a;
	while (a && a->next)
	{
		if (a->indice > a->next->indice)
			breaks++;
		a = a->next;
	}
	if (a && a->next == NULL && a->indice > start->indice)
		breaks++;
	return (breaks <= 1);
}

int	processa_input(int argc, char **argv, t_pilha **a)
{
	int		count;
	int		i;
	t_ints	*n;

	count = 0;
	n = malloc(sizeof(t_ints));
	if (!n)
		return (0);
	n->i = argc - 1;
	i = 1;
	while (i <= n->i)
	{
		if ((argv[i][0] == '\0') || (!is_args_digit(argv[i])))
		{
			return (free(n), 0);
		}
		i++;
	}
	if (!processa_argumentos(argv, &n, a))
		return (free(n), 0);
	free(n);
	return (1);
}

int	main(int argc, char **argv)
{
	t_pilha	*a;
	t_pilha	*b;

	a = NULL;
	b = NULL;
	if (argc == 1)
		return (0);
	if (!processa_input(argc, argv, &a))
		return (write(2, "Error\n", 6), 1);
	if (tem_duplicatas(a))
		return (msg_error("Error\n", a), 1);
	atribuir_indices(a);
	while (!stack_sorted2(a))
		control(&a, &b);
	while (b)
		control_b_to_a(&a, &b);
	align_stack(&a);
	liberar_pilha(a);
	free(b);
	return (0);
}
