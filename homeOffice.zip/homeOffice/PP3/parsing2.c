/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing2.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/05 10:25:51 by bepereir          #+#    #+#             */
/*   Updated: 2025/12/04 15:29:54 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

void	free_tokens(char **tokens)
{
	int	i;

	if (!tokens)
		return ;
	i = 0;
	while (tokens[i])
	{
		free(tokens[i]);
		i++;
	}
	free(tokens);
}

int	ft_strlen(const char *c)
{
	int	i;

	i = 0;
	if (!c)
		return (0);
	while (c[i])
		i++;
	return (i);
}

char	*ft_strchr(const char *s, int c)
{
	int	i;

	i = 0;
	if (!s)
		return (NULL);
	while (s[i] != '\0')
	{
		if (s[i] == (char)c)
			return ((char *)&s[i]);
		i++;
	}
	if (s[i] == (char)c)
		return ((char *)&s[i]);
	return (NULL);
}

static char	*ft_strdup(const char *src)
{
	char	*str;
	size_t	l;
	size_t	c;

	if (!src)
		return (NULL);
	l = ft_strlen(src);
	str = malloc((l + 1) * sizeof(char));
	c = 0;
	if (!str)
		return (NULL);
	while (c < l)
	{
		str[c] = src[c];
		c++;
	}
	str[c] = '\0';
	return (str);
}

char	**add_token(char **list, char *token)
{
	int		len;
	int		i;
	char	**new;

	len = 0;
	i = 0;
	while (list[len])
		len++;
	new = malloc(sizeof(char *) * (len + 2));
	if (!new)
		return (NULL);
	while (i < len)
	{
		new[i] = list[i];
		i++;
	}
	new[len] = ft_strdup(token);
	new[len + 1] = NULL;
	free(list);
	return (new);
}
