/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils6.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/22 21:40:38 by bepereir          #+#    #+#             */
/*   Updated: 2025/12/04 19:48:38 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

long	very_ft_atoi(const char *str)
{
	int		i;
	int		sign;
	long	num;

	i = 0;
	sign = 1;
	num = 0;
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
		i++;
	if (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
			sign = -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		num = num * 10 + (str[i] - '0');
		i++;
	}
	if ((num * sign) > INT_MAX || (num * sign) < INT_MIN)
		return (0);
	return (1);
}

static int	ft_isdigit(char c)
{
	if (c < 48 || c > 57)
		return (0);
	return (1);
}

static void	aux2_is_args_digit(const char *s, int *i)
{
	while (s[*i] == ' ' || s[*i] == 9)
		*i = *i + 1;
}

static int	aux_is_args_digit(const char *s, int *i, int *has_digit)
{
	while (s[*i])
	{
		if (s[*i] == '+' || s[*i] == '-')
		{
			if (*has_digit == 1)
				return (0);
			if (!ft_isdigit(s[*i + 1]))
				return (0);
			*i = *i + 1;
		}
		if (ft_isdigit(s[*i]))
		{
			*has_digit = 1;
			while (ft_isdigit(s[*i]))
				*i = *i + 1;
		}
		else if (s[*i] == ' ' || s[*i] == 9)
		{
			aux2_is_args_digit(s, i);
			*has_digit = 2;
		}
		else
			return (0);
	}
	return (1);
}

int	is_args_digit(const char *s)
{
	int	i;
	int	has_digit;

	i = 0;
	has_digit = 0;
	while (s[i] == ' ')
		i++;
	if (s[i] == '\0')
		return (0);
	if (!aux_is_args_digit(s, &i, &has_digit))
		return (0);
	return (has_digit);
}
