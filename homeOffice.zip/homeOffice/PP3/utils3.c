/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils3.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/26 11:54:34 by bepereir          #+#    #+#             */
/*   Updated: 2025/10/29 11:45:28 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pushswap.h"

void	operate2(t_pilha **vistor, t_pilha **checker, int distA, int distB)
{
	if (distA == CASO_PARTICULAR && distB == CASO_PARTICULAR)
	{
		ft_rrr(vistor, checker);
		return ;
	}
	while (distA > 0 && distB > 0)
	{
		ft_rr(vistor, checker);
		distA--;
		distB--;
	}
	while (distB > 0)
	{
		ft_rb(checker);
		distB--;
	}
	while (distA > 0)
	{
		ft_ra(vistor);
		distA--;
	}
}

void	operate3(t_pilha **vistor, t_pilha **checker, int distA, int distB)
{
	if (distB == CASO_PARTICULAR)
		ft_rrb(checker);
	if (distA == CASO_PARTICULAR)
		ft_rra(vistor);
	while (distA < 0 && distB < 0 && distB != CASO_PARTICULAR
		&& distA != CASO_PARTICULAR)
	{
		ft_rrr(vistor, checker);
		distA++;
		distB++;
	}
	while (distB < 0 && distB != CASO_PARTICULAR)
	{
		ft_rrb(checker);
		distB++;
	}
	while (distA < 0 && distA != CASO_PARTICULAR)
	{
		ft_rra(vistor);
		distA++;
	}
}

void	control_b_to_a(t_pilha **a, t_pilha **b)
{
	t_tpilha	pilha_set;
	int			elemento_a;
	int			elemento_b;
	int			min_moves;
	t_pilha		*target_node;

	if (!a || !b || !*a || !*b)
		return ;
	pilha_set.a = *a;
	pilha_set.b = *b;
	min_moves = INT_MAX;
	pilha_set.deep_a = 0;
	while (pilha_set.b != NULL)
	{
		pilha_set.deep_a = find_target_in_a(*a, pilha_set.b->indice);
		target_node = find_node_by_index(*a, pilha_set.deep_a);
		pilha_set.deep_a = how_deep(target_node->indice, *a);
		if (pilha_set.deep_a < 0)
			pilha_set.deep_a *= -1;
		control2_b_to_a(pilha_set, &min_moves, &elemento_a, &elemento_b);
		pilha_set.b = pilha_set.b->next;
	}
	operate_b_to_a(a, b, how_deep(elemento_a, *a), how_deep(elemento_b, *b));
}

void	control2_b_to_a(t_tpilha pilha_set, int *min_moves, int *elemento_a,
		int *elemento_b)
{
	int	cost;
	int	target;

	target = find_target_in_a(pilha_set.a, pilha_set.b->indice);
	pilha_set.deep_b = how_deep(pilha_set.b->indice, pilha_set.b);
	if (pilha_set.deep_b < 0)
		pilha_set.deep_b *= -1;
	pilha_set.deep_a = how_deep(target, pilha_set.a);
	if (pilha_set.deep_a < 0)
		pilha_set.deep_a *= -1;
	cost = pilha_set.deep_a + pilha_set.deep_b;
	if (cost < *min_moves)
	{
		*min_moves = cost;
		*elemento_a = target;
		*elemento_b = pilha_set.b->indice;
	}
}

int	find_target_in_a(t_pilha *a, int b_index)
{
	t_pilha	*tmp;
	int		target_index;
	int		diff;

	tmp = a;
	target_index = -1;
	diff = INT_MAX;
	while (tmp)
	{
		if (tmp->indice > b_index && (tmp->indice - b_index) < diff)
		{
			diff = tmp->indice - b_index;
			target_index = tmp->indice;
		}
		tmp = tmp->next;
	}
	if (target_index == -1)
		return (find_min_index(a));
	return (target_index);
}
