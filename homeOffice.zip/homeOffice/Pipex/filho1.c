/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   filho1.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/03 09:03:19 by bepereir          #+#    #+#             */
/*   Updated: 2025/11/03 09:07:13 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

void	filho1_process(char **argv, char **envp, int *pipefd)
{
	int		infile;
	char	**cmd;
	char	*path;

	infile = open(argv[1], O_RDONLY);
	if (infile < 0)
		error_exit("infile");

	dup2(infile, STDIN_FILENO);
	dup2(pipefd[1], STDOUT_FILENO);

	close(pipefd[0]);
	close(pipefd[1]);
	close(infile);

	cmd = ft_split(argv[2], ' ');
	path = get_cmd_path(cmd[0], envp);
	if (!path)
	{
		free_split(cmd);
		error_exit("command not found");
	}
	execve(path, cmd, envp);
	perror("execve");
	free(path);
	free_split(cmd);
	exit(EXIT_FAILURE);
}
