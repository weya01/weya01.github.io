/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/03 09:06:07 by bepereir          #+#    #+#             */
/*   Updated: 2025/11/03 09:06:54 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

void	error_exit(const char *msg)
{
	perror(msg);
	exit(EXIT_FAILURE);
}

void	free_split(char **arr)
{
	int	i;

	if (!arr)
		return;
	i = 0;
	while (arr[i])
		free(arr[i++]);
	free(arr);
}

char	*join_path(char *dir, char *cmd)
{
	char	*path;
	int		len = strlen(dir) + strlen(cmd) + 2;

	path = malloc(len);
	if (!path)
		return (NULL);
	snprintf(path, len, "%s/%s", dir, cmd);
	return (path);
}

char	*get_cmd_path(char *cmd, char **envp)
{
	char	**paths;
	char	*path;
	int		i = 0;
	char	*env_path = NULL;

	while (envp[i])
	{
		if (strncmp(envp[i], "PATH=", 5) == 0)
		{
			env_path = envp[i] + 5;
			break;
		}
		i++;
	}
	if (!env_path)
		return (NULL);
	paths = ft_split(env_path, ':');
	i = 0;
	while (paths[i])
	{
		path = join_path(paths[i], cmd);
		if (access(path, X_OK) == 0)
		{
			free_split(paths);
			return (path);
		}
		free(path);
		i++;
	}
	free_split(paths);
	return (NULL);
}

/* Implementação simples de ft_split */
char	**ft_split(char const *s, char c)
{
	char	**result;
	int		i, j, k, words;

	if (!s)
		return (NULL);
	for (i = 0, words = 0; s[i]; i++)
		if ((s[i] != c && (i == 0 || s[i - 1] == c)))
			words++;
	result = malloc((words + 1) * sizeof(char *));
	if (!result)
		return (NULL);
	i = 0; j = 0;
	while (s[i])
	{
		while (s[i] && s[i] == c)
			i++;
		k = i;
		while (s[i] && s[i] != c)
			i++;
		if (i > k)
			result[j++] = strndup(s + k, i - k);
	}
	result[j] = NULL;
	return (result);
}
