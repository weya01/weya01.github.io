/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   filho2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/03 09:05:19 by bepereir          #+#    #+#             */
/*   Updated: 2025/11/03 09:07:08 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

void	filho2_process(char **argv, char **envp, int *pipefd)
{
	int		outfile;
	char	**cmd;
	char	*path;

	outfile = open(argv[4], O_WRONLY | O_CREAT | O_TRUNC, 0644);
	if (outfile < 0)
		error_exit("outfile");

	dup2(pipefd[0], STDIN_FILENO);
	dup2(outfile, STDOUT_FILENO);

	close(pipefd[0]);
	close(pipefd[1]);
	close(outfile);

	cmd = ft_split(argv[3], ' ');
	path = get_cmd_path(cmd[0], envp);
	if (!path)
	{
		free_split(cmd);
		error_exit("command not found");
	}
	execve(path, cmd, envp);
	perror("execve");
	free(path);
	free_split(cmd);
	exit(EXIT_FAILURE);
}
