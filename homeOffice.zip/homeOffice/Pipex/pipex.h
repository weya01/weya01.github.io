/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/03 09:02:37 by bepereir          #+#    #+#             */
/*   Updated: 2025/11/03 09:03:47 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PIPEX_H
# define PIPEX_H

# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include <string.h>
# include <sys/wait.h>
# include <errno.h>

void	error_exit(const char *msg);
char	*get_cmd_path(char *cmd, char **envp);
char	**ft_split(char const *s, char c);
void	free_split(char **arr);

void	filho1_process(char **argv, char **envp, int *pipefd);
void	filho2_process(char **argv, char **envp, int *pipefd);

#endif
