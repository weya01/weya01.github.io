/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_map.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/12/05 11:48:02 by bepereir          #+#    #+#             */
/*   Updated: 2025/12/05 11:57:20 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include "so_long.h"

//  1. Receber mapa .ber
//  2. Validar o Mapa (apenas .ber > strchr(".ber"))
//  2.1 Usar flodfill para certificar acesso aos colecionaveis e a saida
//  3. Criar janela usando minLibX
//  4. Carregar texturas (sprites) usando minLibX
//  5. Movimentacao do player usando minLibX (teclado)
//  6. Terminar processos minLibX


//  1. Receber mapa .ber
    // Usar getNextLine para aceder um ficheiro
    // Salvar ficehiro dentro de matriz (**map)
    




//  2. Validar o Mapa
//  3. Criar janela usando minLibX
//  4. Carregar texturas (sprites) usando minLibX
//  5. Movimentacao do player usando minLibX (teclado)
//  6. Terminar processos minLibX