/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/10 18:01:15 by bepereir          #+#    #+#             */
/*   Updated: 2025/11/12 11:36:12 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBFT_H
# define LIBFT_H

//#include <string.h>
# include <stddef.h>
# include <stdlib.h>
# include <unistd.h>

int					ft_atoi(const char *str);
int					ft_isdigit(int c);
size_t				ft_strlen(const char *c);
char				**ft_split(char const *s, char c);


#endif
