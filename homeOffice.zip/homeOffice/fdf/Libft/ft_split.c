/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/14 00:51:06 by bepereir          #+#    #+#             */
/*   Updated: 2025/06/26 17:29:39 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	qnt_wrds(const char *s, char c)
{
	int	count;
	int	in_word;

	count = 0;
	in_word = 0;
	if (!s)
		return (0);
	while (*s)
	{
		if (*s != c && in_word == 0)
		{
			in_word = 1;
			count++;
		}
		else if (*s == c)
			in_word = 0;
		s++;
	}
	return (count);
}

static char	*ft__strndup(const char *src, int n)
{
	char	*dest;
	int		i;

	dest = (char *)malloc(sizeof(char) * (n + 1));
	if (!dest)
		return (NULL);
	i = 0;
	while (i < n && src[i])
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

static char	**cpy_split(const char *s, int wrds, char c)
{
	char	**mat;
	int		i;
	int		j;
	int		start;

	i = 0;
	j = 0;
	start = 0;
	mat = (char **)malloc(sizeof(char *) * (wrds + 1));
	if (!mat)
		return (NULL);
	while (s[i] && j < wrds)
	{
		while (s[i] == c)
			i++;
		start = i;
		while (s[i] && s[i] != c)
			i++;
		if (i > start)
			mat[j++] = ft__strndup(s + start, i - start);
	}
	mat[j] = NULL;
	return (mat);
}

char	**ft_split(char const *s, char c)
{
	char	**new;
	int		count_words;

	if (!s)
		return (NULL);
	count_words = qnt_wrds(s, c);
	new = cpy_split(s, count_words, c);
	return (new);
}
