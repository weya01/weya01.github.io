/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/13 12:56:51 by bepereir          #+#    #+#             */
/*   Updated: 2025/07/03 17:28:36 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static const char	*aux(const char *nptr)
{
	const char	*n;

	while (*nptr == 32 || (*nptr < 14 && *nptr > 8))
		nptr++;
	n = nptr;
	return (n);
}

static long	aux2(char *nptr, long num)
{
	int	sgn;

	sgn = 0;
	if (num == -1)
	{
		num = 0;
		sgn = -1;
	}
	while (ft_isdigit(*nptr))
	{
		num = num * 10 + (*nptr - '0');
		nptr++;
	}
	if (sgn == -1)
		num *= -1;
	if (num == -2147483648 || num == 2147483648)
		return (-2147483648);
	if (num < -2147483648)
		return (0);
	if (num > 2147483647)
		return (-1);
	return (num);
}

int	ft_atoi(const char *nptr)
{
	long	num;
	char	*n;

	num = 0;
	if (!nptr)
		return (0);
	nptr = aux(nptr);
	if (*nptr == 45 || *nptr == '+')
	{
		if (*nptr == 45)
			num = -1;
		nptr++;
	}
	if (!ft_isdigit(*nptr))
		return (0);
	n = (char *)nptr;
	num = aux2(n, num);
	return ((int)(num));
}
