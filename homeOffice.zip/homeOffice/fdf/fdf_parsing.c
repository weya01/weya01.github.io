/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf_parsing.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/12 09:02:15 by bepereir          #+#    #+#             */
/*   Updated: 2025/12/05 09:44:54 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

int	count_numbers(char *line)
{
	int	count;
	int	i;

    count = 0;
    i = 0;
	while (line[i])
	{
		while (line[i] == ' ')
			i++;
		if (line[i] && line[i] != ' ')
		{
			count++;
			while (line[i] && line[i] != ' ')
				i++;
		}
	}
	return (count);
}

static int	*parse_line(char *line, int width)
{
	char	**nums;
	int		*row;
	int		i;

    i = 0;
    nums = ft_split(line, ' ');
	row = malloc(sizeof(int) * width);
	if (!row)
		return (NULL);
	while (nums[i])
	{
		row[i] = ft_atoi(nums[i]);
		free(nums[i]);
		i++;
	}
	free(nums);
	return (row);
}

void	fill_z_matrix(t_map *map, int fd)
{
	char	*line;
	int		y;

	map->z_matrix = malloc(sizeof(int *) * map->height);
	if (!map->z_matrix)
		return ;
	y = 0;
    line = get_next_line(fd);
	while (line)
	{
		map->z_matrix[y] = parse_line(line, map->width);
		free(line);
        y++;
        line = get_next_line(fd);
	}
}

t_map	*read_map(char *file)
{
	t_map	*map;
	int		fd;

	fd = open(file, O_RDONLY);
	if (fd < 0)
		return (NULL);
	map = malloc(sizeof(t_map));
	if (!map)
		return (NULL);
	count_dimensions(map, fd);
	close(fd);
	fd = open(file, O_RDONLY);
	if (fd < 0)
		return (free(map), NULL);
	fill_z_matrix(map, fd);
	close(fd);
	return (map);
}

int	main(int argc, char **argv)
{
	t_map *map;
	int y;
    int x;

	x = 0;
    y = 0;
    if (argc != 2)
		return (ft_printf("Uso: %s <ficheiro.fdf>\n", argv[0]),1);
	map = read_map(argv[1]);
	if (!map)
		return (ft_printf("Erro a ler o ficheiro.\n"), 1);
	ft_printf("Mapa lido com sucesso: %d x %d\n", map->width, map->height);
	while (y < map->height)
    {
        while (x < map->width)
        {
            ft_printf("%d ", map->z_matrix[y][x]);
            x++;
        }
        ft_printf("\n");
        y++;
    }
	return (0);
}
