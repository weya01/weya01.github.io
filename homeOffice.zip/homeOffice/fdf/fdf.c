/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/12 08:45:06 by bepereir          #+#    #+#             */
/*   Updated: 2025/11/12 08:50:44 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include "fdf.h"

/*VI.1 Rendering
Your program has to represent the model in isometric projection.
The coordinates of the landscape are stored in a .fdf file, provided as a command
line parameter to your program. Here is an example:
$>cat 42.fdf
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 10 10 0 0 10 10 0 0 0 10 10 10 10 10 0 0 0
0 0 10 10 0 0 10 10 0 0 0 0 0 0 0 10 10 0 0
0 0 10 10 0 0 10 10 0 0 0 0 0 0 0 10 10 0 0
0 0 10 10 10 10 10 10 0 0 0 0 10 10 10 10 0 0 0
0 0 0 10 10 10 10 10 0 0 0 10 10 0 0 0 0 0 0
0 0 0 0 0 0 10 10 0 0 0 10 10 0 0 0 0 0 0
0 0 0 0 0 0 10 10 0 0 0 10 10 10 10 10 10 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
$>

Each number represents a point in space:
• The horizontal position corresponds to its abscissa.
• The vertical position corresponds to its ordinate.
• The value corresponds to its altitude.
Executing your fdf program using the example file 42.fdf:
$>./fdf 42.fdf
$>
Should render a landscape similar to:
    42

Remember to use your libft in the best way possible! Using get_next_line(),
ft_split() and other functions will allow you to read data from the file in a quick and
simple way.
Keep in mind that the goal of this project is not to parse maps! However, this doesn’t
mean that your program should crash when run. It means that we assume the map
contained in the file is properly formatted.
*/

/*
VI.2 Graphic management
• Your program has to display the image in a window.
• Window management must remain smooth (e.g., switching to another window,
minimizing, etc.).
• Pressing ESC must close the window and quit the program in a clean way.
• Clicking on the cross on the window’s frame must close the window and quit the
program in a clean way.
• The use of the images of the MiniLibX library is mandatory.
*/