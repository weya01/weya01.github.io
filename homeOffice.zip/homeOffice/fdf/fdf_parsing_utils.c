/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf_parsing_utils.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/12 10:22:33 by bepereir          #+#    #+#             */
/*   Updated: 2025/11/12 10:48:06 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include "fdf.h"

void	free_map(t_map *map)
{
	int	i;

	i = 0;
	if (!map)
		return;
	while (i < map->height)
	{
		free(map->z_matrix[i]);
		i++;
	}
	free(map->z_matrix);
	free(map);
}

void	count_dimensions(t_map *map, int fd)
{
	char	*line;

	map->height = 0;
	map->width = 0;
	while ((line = get_next_line(fd)))
	{
		if (map->width == 0)
			map->width = count_numbers(line);
		map->height++;
		free(line);
	}
}

