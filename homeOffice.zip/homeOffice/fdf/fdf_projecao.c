/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf_projecao.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/12 09:12:50 by bepereir          #+#    #+#             */
/*   Updated: 2025/12/05 10:48:35 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include "fdf.h"

/*
🧮 3. Projeção 3D → 2D (Isométrica)

Objetivo: transformar as coordenadas (x, y, z) em (x’, y’) para desenhar.

Fórmula típica da projeção isométrica:

x_iso = (x - y) * cos(30°);     cos(30º) = 0.866
y_iso = (x + y) * sin(30°) - z; sin(30º) = 0.5


Ajusta z para controlar a altura (podes multiplicar por um fator).

Podes adicionar um offset para centralizar o mapa na janela.
🔹 3.3. Escala e centralização

Após aplicares a projeção, os pontos podem ficar muito pequenos ou fora da janela.

Então:

Multiplica (x, y, z) por um fator de escala (zoom).

Adiciona offsets (shift_x, shift_y) para centralizar.

x_iso *= zoom;
y_iso *= zoom;
x_iso += shift_x;
y_iso += shift_y;

🔹 3.5. Bresenham: desenhar linhas

Para ligar os pontos, usa o algoritmo de Bresenham, que desenha uma linha entre dois pontos (x1, y1) e (x2, y2) pixel a pixel, sem buracos e sem floats.

Pseudocódigo simplificado:

void draw_line(t_point a, t_point b, t_data *img)
{
    float dx = fabs(b.x - a.x);
    float dy = fabs(b.y - a.y);
    float sx = (a.x < b.x) ? 1 : -1;
    float sy = (a.y < b.y) ? 1 : -1;
    float err = dx - dy;

    while (1)
    {
        put_pixel(img, a.x, a.y, color);
        if (a.x == b.x && a.y == b.y)
            break;
        float e2 = 2 * err;
        if (e2 > -dy) { err -= dy; a.x += sx; }
        if (e2 < dx) { err += dx; a.y += sy; }
    }
}




🧰 4. MiniLibX (mlx)

Objetivo: abrir uma janela e desenhar linhas.
Inicializa a mlx:

void *mlx = mlx_init();
void *win = mlx_new_window(mlx, WIDTH, HEIGHT, "FdF");

Usa mlx_pixel_put() (para testar) e depois implementa Bresenham’s line algorithm para desenhar linhas entre pontos adjacentes.

Guarda tudo numa imagem (mlx_new_image) e faz mlx_put_image_to_window() para evitar flickering.

🧰 O que é:
A MiniLibX (ou MLX) é uma mini biblioteca gráfica criada pela 42.
É uma camada simples sobre o X11 (Linux/macOS), que te permite:

Criar janelas
Desenhar pixels, imagens e texto
Capturar eventos (teclas, rato, etc.)
👉 É bem low-level: tu tens de tratar de cada pixel manualmente.

🔹 4.1. Funções principais
Inicialização e janela:
void *mlx = mlx_init();
void *win = mlx_new_window(mlx, WIDTH, HEIGHT, "FdF");

Desenhar um pixel diretamente:
mlx_pixel_put(mlx, win, x, y, color);


⚠️ Isto é lento se usares muitos pixels — é melhor usar imagens.

🔹 4.2. Usar imagens para desenhar

Cria uma imagem na memória e manipula o buffer diretamente:

img.img = mlx_new_image(mlx, WIDTH, HEIGHT);
img.addr = mlx_get_data_addr(img.img, &img.bits_per_pixel,
                             &img.line_length, &img.endian);


Depois:

void my_mlx_pixel_put(t_img *img, int x, int y, int color)
{
    char *dst = img->addr + (y * img->line_length + x * (img->bits_per_pixel / 8));
    *(unsigned int*)dst = color;
}


E finalmente desenhas tudo na janela:

mlx_put_image_to_window(mlx, win, img.img, 0, 0);

🔹 4.3. Hooks de eventos

Para interagir com o teclado e rato:

mlx_hook(win, 2, 1L<<0, key_press, &data);    // key down
mlx_hook(win, 17, 0, close_window, &data);    // fechar janela (X)
mlx_loop(mlx);


🎮 5. Controlo de input

Objetivo: permitir ao utilizador mover, rodar, e dar zoom.

Garante que mlx_hook() está configurado para capturar eventos:

Setas para mover.

+/- para zoom.

R para resetar vista.

Atualiza o mapa e redesenha a imagem.

int key_press(int keycode, t_data *data)
{
    if (keycode == 65307) // ESC
        exit(0);
    else if (keycode == 65362) // seta cima
        data->shift_y -= 10;
    else if (keycode == 65364) // seta baixo
        data->shift_y += 10;
    else if (keycode == 65361) // seta esquerda
        data->shift_x -= 10;
    else if (keycode == 65363) // seta direita
        data->shift_x += 10;
    else if (keycode == 65451) // +
        data->zoom += 1;
    else if (keycode == 65453) // -
        data->zoom -= 1;
    draw(data); // redesenha com as novas coordenadas
    return (0);
}




🎨 6. Cores (opcional mas recomendado)

Podes interpolar cores com base em z (altitude).

Exemplo:

z <= 0: azul.

z > 0: passa de verde → amarelo → vermelho.

Dá mais vida ao wireframe.

🧹 7. Organização e limpeza

Divide o código em ficheiros:

src/
  main.c
  parse_map.c
  draw.c
  projection.c
  events.c
  utils.c
includes/
  fdf.h


Liberta memória (free) antes de sair.

Faz Makefile com regras: all, clean, fclean, re.

✅ 8. Testes e refinamentos

Testa com vários mapas .fdf (42 fornece alguns).

Testa casos extremos: mapa pequeno, gigante, linhas desiguais.

Confirma que não há leaks (valgrind).

🗺️ Resumo rápido
Etapa	Tópico	Objetivo
1	Leitura	Ler e guardar o mapa
2	Projeção	Converter 3D → 2D
3	Desenho	Desenhar linhas com Bresenham
4	Controlo	Interagir com o mapa
5	Cores	Dar profundidade visual
6	Refino	Limpeza, Makefile, testes
*/