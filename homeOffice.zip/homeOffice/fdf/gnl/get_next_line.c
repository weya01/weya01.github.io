/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/18 12:43:22 by bepereir          #+#    #+#             */
/*   Updated: 2025/07/22 14:25:49 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

static char	*get_new_line(char *content)
{
	size_t	i;
	char	*linha;

	i = 0;
	if (!content || !content[0])
		return (NULL);
	while (content[i] && content[i] != '\n')
		i++;
	if (content[i] == '\n')
		i++;
	linha = malloc(i + 1);
	if (!linha)
		return (NULL);
	i = 0;
	while (content[i] && content[i] != '\n')
	{
		linha[i] = content[i];
		i++;
	}
	if (content[i] == '\n')
		linha[i++] = '\n';
	linha[i] = '\0';
	return (linha);
}

static char	*clean_content(char *content)
{
	size_t	i;
	char	*new_content;

	i = 0;
	if (!content)
		return (NULL);
	while (content[i] != '\0' && content[i] != '\n')
		i++;
	if (!content[i])
	{
		free(content);
		return (NULL);
	}
	new_content = ft_substr(content, i + 1, ft_strlen(content) - i - 1);
	free(content);
	return (new_content);
}

static char	*read_and_store(int fd, char *content)
{
	char	buffer[BUFFER_SIZE + 1];
	ssize_t	bytes_readed;

	bytes_readed = 1;
	while (!ft_strchr(content, '\n') && bytes_readed > 0)
	{
		bytes_readed = read(fd, buffer, BUFFER_SIZE);
		if (bytes_readed < 0)
			return (NULL);
		buffer[bytes_readed] = '\0';
		content = ft_strjoin(content, buffer);
		if (!content)
			return (NULL);
	}
	return (content);
}

char	*get_next_line(int fd)
{
	static char	*content;
	char		*linha;

	if (fd < 0 || BUFFER_SIZE <= 0)
		return (NULL);
	content = read_and_store(fd, content);
	if (!content)
		return (NULL);
	linha = get_new_line(content);
	content = clean_content(content);
	return (linha);
}
