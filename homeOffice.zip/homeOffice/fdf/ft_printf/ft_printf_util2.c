/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_util2.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/16 03:51:27 by bepereir          #+#    #+#             */
/*   Updated: 2025/07/16 04:13:47 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_putchar_fd(char c, int fd)
{
	return ((int)write(fd, &c, 1));
}

int	ft_putnbr_hex_lo(unsigned long num, int fd)
{
	int		o;
	char	*h;

	h = "0123456789abcdef";
	o = 0;
	if (num >= 16)
		o += ft_putnbr_hex_lo(num / 16, fd);
	ft_putchar_fd(h[(num % 16)], fd);
	return (o + 1);
}

int	ft_putnbr_hex_up(unsigned long num, int fd)
{
	int		o;
	char	*h;

	h = "0123456789ABCDEF";
	o = 0;
	if (num >= 16)
		o += ft_putnbr_hex_up(num / 16, fd);
	ft_putchar_fd(h[(num % 16)], fd);
	return (o + 1);
}

int	ft_putnbr_unsg(unsigned int num, int fd)
{
	int	o;

	o = 0;
	if (num >= 10)
		o += ft_putnbr_unsg(num / 10, fd);
	ft_putchar_fd((num % 10) + '0', fd);
	return (o + 1);
}

int	ft_putptr(void *p, int fd)
{
	int				o;
	unsigned long	addr;

	o = 0;
	addr = (unsigned long)p;
	if (!p)
		return ((int)write(1, "(nil)", 5));
	else
	{
		o += (int)write(1, "0x", 2);
		o += ft_putnbr_hex_lo(addr, fd);
	}
	return (o);
}
