/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_util.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/16 03:58:20 by bepereir          #+#    #+#             */
/*   Updated: 2025/07/16 04:04:57 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_putchar_fd2(char c, int fd)
{
	return ((int)write(fd, &c, 1));
}

int	ft_putnbr_fd(int n, int fd)
{
	int	o;

	o = 0;
	if (n == -2147483648)
		return ((int)write(fd, "-2147483648", 11));
	if (n < 0)
	{
		o += ft_putchar_fd('-', fd);
		n = -n;
	}
	if (n >= 10)
		o += ft_putnbr_fd(n / 10, fd);
	ft_putchar_fd2((n % 10) + '0', fd);
	return (o + 1);
}

int	ft_putstr_fd(char *s, int fd)
{
	int	o;

	o = 0;
	if (!s)
		return ((int)write(fd, "(null)", 6));
	while (*s)
		o += ((int)write(fd, s++, 1));
	return (o);
}
