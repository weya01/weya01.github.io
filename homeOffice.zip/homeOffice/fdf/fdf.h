/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bepereir <bepereir@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/12 09:42:08 by bepereir          #+#    #+#             */
/*   Updated: 2025/11/12 11:37:06 by bepereir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FDF_H
# define FDF_H

#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <math.h>
#include "gnl/get_next_line.h"  // se estiveres a usar GNL
#include "Libft/libft.h"
#include "ft_printf/ft_printf.h"

typedef struct s_map
{
	int     **z_matrix;   // matriz [y][x] com alturas
	int		width;        // nº de colunas
	int		height;       // nº de linhas
}	t_map;

// parsing
t_map	*read_map(char *file);
void	free_map(t_map *map);
void	count_dimensions(t_map *map, int fd);
int	    count_numbers(char *line);



#endif
