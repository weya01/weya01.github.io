from pysnmp.hlapi import *
from datetime import datetime
import logging

logger = logging.getLogger("SNMPCollector")

def snmp_get(host: str, community: str, oid: str, port: int = 161) -> str:
    iterator = getCmd(
        SnmpEngine(),
        CommunityData(community, mpModel=1),  # SNMP v2c
        UdpTransportTarget((host, port)),
        ContextData(),
        ObjectType(ObjectIdentity(oid))
    )

    errorIndication, errorStatus, errorIndex, varBinds = next(iterator)

    if errorIndication:
        raise Exception(f"SNMP error: {errorIndication}")
    elif errorStatus:
        raise Exception(f"SNMP error: {errorStatus.prettyPrint()}")
    else:
        for varBind in varBinds:
            return str(varBind[1])

def collect_snmp_metrics(host: str, community: str = "public", port: int = 161) -> dict:
    try:
        data = {
            "timestamp": datetime.utcnow().isoformat(),
            "host": host,
            "success": True,
            "system_name": snmp_get(host, community, "1.3.6.1.2.1.1.5.0", port),
            "system_desc": snmp_get(host, community, "1.3.6.1.2.1.1.1.0", port),
            "uptime": snmp_get(host, community, "1.3.6.1.2.1.1.3.0", port),
        }
    except Exception as e:
        data = {
            "timestamp": datetime.utcnow().isoformat(),
            "host": host,
            "success": False,
            "error": str(e)
        }

    return data
