from ping3 import ping
from app.models.service import ServiceStatus

def get_service_status(service_id: int) -> ServiceStatus:
    if service_id == 1:
        latency = ping("8.8.8.8")
        status = "up" if latency else "down"
        return ServiceStatus(id=1, name="Google DNS", status=status, latency=latency)
    return ServiceStatus(id=service_id, name="Unknown", status="down")

