from fastapi import APIRouter, HTTPException
from app.models.service import ServiceStatus
from app.services.ping_service import get_service_status
from app.core.database import get_connection

from app.services.snmp_collector import collect_snmp_metrics
from app.models.monitoring import MonitoringEntry
from app.core.database import get_db
from sqlalchemy.orm import Session

from fastapi import Depends

from datetime import datetime



router = APIRouter()

@router.get("/services/{service_id}", response_model=ServiceStatus)
async def read_service_status(service_id: int):
    status = get_service_status(service_id)
    conn = await get_connection()
    await conn.execute("""
        INSERT INTO services (id, name, last_status, latency)
        VALUES ($1, $2, $3, $4)
        ON CONFLICT (id) DO UPDATE SET last_status = $3, latency = $4
    """, status.id, status.name, status.status, status.latency)
    await conn.close()
    return status

@router.get("/services/", response_model=list[ServiceStatus])
async def read_all_services():
    conn = await get_connection()
    rows = await conn.fetch("SELECT id, name, last_status FROM services")
    await conn.close()
    return [ServiceStatus(id=row['id'], name=row['name'], status=row['last_status']) for row in rows]


@router.post("/monitor/snmp", response_model=None)
def monitor_snmp(
    host: str, 
    community: str = "public", 
    db: Session = Depends(get_db)
):
    result = collect_snmp_metrics(host=host, community=community)

    entry = MonitoringEntry(
        host=host,
        data_type="snmp",
        timestamp=datetime.utcnow(),
        data=result
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)

    if not result["success"]:
        raise HTTPException(status_code=500, detail=result["error"])

    return {"message": "SNMP data collected", "entry": result}
