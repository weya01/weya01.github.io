from fastapi import WebSocket
import asyncio
from app.services.ping_service import get_service_status

async def check_services():
    tasks = [get_service_status(i) for i in range(1, 4)]
    return tasks

async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    while True:
        data = await check_services()
        await websocket.send_json([s.dict() for s in data])
        await asyncio.sleep(5)

