from pydantic import BaseModel

class ServiceStatus(BaseModel):
    id: int
    name: str
    status: str
    latency: float | None = None

