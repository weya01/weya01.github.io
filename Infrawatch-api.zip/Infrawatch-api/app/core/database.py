# app/core/database.py
import psycopg2
from psycopg2.extras import RealDictCursor
from contextlib import contextmanager

from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base


@contextmanager
def get_connection():
    conn = psycopg2.connect(
        dbname="infrawatch",
        user="akupesa",
        password="Anderson26$"
    )
    try:
        yield conn
    finally:
        conn.close()

DATABASE_URL = "sqlite:///./infrawatch.db"  # ou o caminho do seu banco

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)

Base = declarative_base()

def get_db():
    db: Session = SessionLocal()
    try:
        yield db
    finally:
        db.close()
