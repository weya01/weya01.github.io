
# InfraWatch API by akupesa (Crusaiders Team)

import os
import asyncio
import logging
import psycopg2
from ping3 import ping
from fastapi import FastAPI
from fastapi import WebSocket
from app.api.routes import router
from pydantic import BaseModel
from app.api.websocket import websocket_endpoint

from fastapi import HTTPException, Header
from typing import Optional, Dict, Any

from sqlalchemy.orm import Session
from app.models.monitoring import MonitoringEntry  # seu modelo ORM




app = FastAPI(title="InfraWatch API")
app.include_router(router)

class MonitoringData(BaseModel):
    host: str
    type: str
    timestamp: str
    data: Dict[str, Any]

API_TOKEN = "SEU_TOKEN_AQUI"

@app.post("/monitoring/data")
async def receive_data(monitoring_data: MonitoringData, authorization: Optional[str] = Header(None)):
    if authorization != f"Bearer {API_TOKEN}":
        raise HTTPException(status_code=401, detail="Unauthorized")

    # Aqui, chame função para salvar no banco (exemplo abaixo)
    save_monitoring_data(monitoring_data)
    return {"status": "success", "message": "Dados recebidos"}

def save_monitoring_data(monitoring_data: MonitoringData):
    db: Session = get_db_session()  # sua função para obter sessão DB

    entry = MonitoringEntry(
        host=monitoring_data.host,
        data_type=monitoring_data.type,
        timestamp=monitoring_data.timestamp,
        data=monitoring_data.data
    )
    db.add(entry)
    db.commit()

class ServiceStatus(BaseModel):
	id: int
	name: str
	status: str
	latency: float = None

def get_service_status(service_id: int):
	if service_id == 1:
		latency = ping("8.8.8.8") # simulação de um ping para o Google DNS
		status = "up" if latency else "down"
		return ServiceStatus(id = 1,
		       name = "Google DNS", 
		       status = status, 
		       latency = latency)
	return ServiceStatus(id = service_id, name = "Unknown", status = "down")

@app.get("/")
async def root():
    return {"message": "InfraWatch API is running"}

# Simulação de um serviço desconhecido
@app.get("/services/{service_id}", response_model=ServiceStatus)
async def read_service_status(service_id: int):
	status = get_service_status(service_id)
	conn = psycopg2.connect("dbname = infrawatch user = akupesa password = 'Anderson26$'")
	cur = conn.cursor()
	cur.execute("INSERT INTO services (id, name, Last_status, latency) VALUES (%s, %s, %s, %s) ON CONFLICT (id) DO UPDATE SET Last_status = %s, latency = %s",
	     (status.id, status.name, status.status, status.latency, status.status, status.latency))
	conn.commit()
	cur.close()
	conn.close()
	return status

#
@app.get("/services/", response_model = list[ServiceStatus])
async def read_all_services():
	conn = psycopg2.connect("dbname = infrawatch user = akupesa password = 'Anderson26$'")
	cur = conn.cursor()
	cur.execute("SELECT id, name, last_status FROM services")
	rows = cur.fetchall()
	services = [ServiceStatus(id = row[0], name = row[1], status = row[2]) for row in rows]
	cur.close
	conn.close
	return services

#@app.websocket("/ws")
#async def websocket(ws: WebSocket):
#    await websocket_endpoint(ws)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    while True:
        data = await check_services()
        await websocket.send_json([s.dict() for s in data])
        await asyncio.sleep(5)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def check_services():
    tasks = [get_service_status(i) for i in range(1, 4)]
    return await asyncio.gather(*tasks)


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port, reload=True)

@app.get("/monitoring/{host}")
async def get_monitoring_data(host: str, data_type: Optional[str] = None):
    db: Session = get_db_session()
    query = db.query(MonitoringEntry).filter(MonitoringEntry.host == host)
    if data_type:
        query = query.filter(MonitoringEntry.data_type == data_type)
    results = query.order_by(MonitoringEntry.timestamp.desc()).limit(100).all()
    return results