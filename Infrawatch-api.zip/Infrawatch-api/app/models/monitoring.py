from sqlalchemy import Column, Integer, String, DateTime, JSON
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class MonitoringEntry(Base):
    __tablename__ = "monitoring_entries"

    id = Column(Integer, primary_key=True, index=True)
    host = Column(String, index=True)
    data_type = Column(String)  # Ex: "ping", "snmp", "nmap"
    timestamp = Column(DateTime, default=datetime.utcnow)
    data = Column(JSON)  # Dados brutos do agente, como JSON serializado
